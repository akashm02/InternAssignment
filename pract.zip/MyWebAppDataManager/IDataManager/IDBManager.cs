﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.IDataManager
{
    public interface IDBManager
    {
        IDBManager InitDbCommand(string cmd);
        IDBManager InitDbCommand(string cmd, CommandType cmdtype);
        IDBManager BeginTransaction();
        IDBManager Commit();
        Task<IDBManager> CommitAsync();
        IDBManager AddCMDParam(string parametername, object value);
        IDBManager AddCMDParam(string parametername, object value, DbType dbtype);
        IDBManager AddCMDOutParam(string parametername, DbType dbtype);

        T GetOutParam<T>(string paramname);
        DataTable ExecuteDataTable();
        DataSet ExecuteDataSet();

        object? ExecuteScalar();

        Task<object?> ExecuteScalarAsync();
        int ExecuteNonQuery();
        Task<int> ExecuteNonQueryAsync();

        //T Get<T>();
        //List<T> GetList<T>();
        //void Execute(string sql, object param = null);
        //object ExecuteScalar(string sql, object param = null);
    }
}
