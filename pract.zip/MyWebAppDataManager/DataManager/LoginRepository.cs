﻿using MyWebAppDataManager.IDataManager;
using MyWebAppModels.Login;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.DataManager
{
    public class LoginRepository : ILoginRepository
    {
        readonly IDBManager _IDbManager;
        private static Logger _logger = LogManager.GetCurrentClassLogger(); 

        public LoginRepository( IDBManager IDbManager )
        {
            _IDbManager = IDbManager;
        }

        public UserModel LoginAuth(LoginModel oModel)
        {
            UserModel userModel = null;

            _IDbManager.InitDbCommand("get_details_forlogin")
                .AddCMDParam("username_in", oModel.Username)
                .AddCMDParam("userpassword_in", oModel.Password)
                .AddCMDOutParam("error_msg_out", DbType.String); // takes the error message from the database
                    
               

            try
            {
                DataTable dt = _IDbManager.ExecuteDataTable();

                userModel = new UserModel();

                userModel.ErrorMessage = _IDbManager.GetOutParam<string>("error_msg_out");

                foreach (DataRow item in dt.Rows)
                {
                    
                    userModel.UserId = Convert.ToInt32(item["user_id"]);
                    userModel.FirstName = Convert.ToString(item["first_name"]);
                    userModel.LastName = Convert.ToString(item["last_name"]);
                    userModel.PhoneNumber = Convert.ToString(item["phone_number"]);
                    userModel.Email = Convert.ToString(item["email"]);
                }

            }
            catch(Exception ex) 
            {
                _logger.Info(ex.Message);
                //Console.WriteLine(ex.Message);  
            }

            
            return userModel;
        }

    }
}
