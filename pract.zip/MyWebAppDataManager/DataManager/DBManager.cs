﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyWebAppDataManager.Extensions;
using MyWebAppDataManager.IDataManager;

namespace MyWebAppDataManager.DataManager
{
    public sealed class DBManager : IDBManager, IDisposable
    {

        private readonly DbConnection _DbConnection;
        private string _DBCmd;
        private CommandType _CommandType;
        private List<DBParam> _InputParam;
        private List<DBParam> _OutParam;
        private DbTransaction? _DbTransaction;


        public DBManager(DbConnection dbcon)
        {
            _DbConnection = dbcon;
        }




        public void Dispose()
        {
            _DbConnection.Close();
            _DbConnection.Dispose();
        }

        async Task OpenAsync()
        {
            if (_DbConnection.State != ConnectionState.Open)
                await _DbConnection.OpenAsync();
        }

        void Open()
        {
            if (_DbConnection.State != ConnectionState.Open)
                _DbConnection.Open();
        }

        public IDBManager InitDbCommand(string cmd)
        {
            InitDbCommand(cmd, CommandType.StoredProcedure);
            return this;
        }

        public IDBManager InitDbCommand(string cmd, CommandType cmdtype)
        {
            _DBCmd = cmd;
            _CommandType = cmdtype;
            _InputParam = new();
            _OutParam = new();
            return this;
        }

        public IDBManager BeginTransaction()
        {
            Open();
            _DbTransaction = _DbConnection.BeginTransaction();
            return this;
        }

        public IDBManager Commit()
        {
            _DbTransaction?.Commit();
            _DbTransaction = null;
            return this;
        }

        public async Task<IDBManager> CommitAsync()
        {
            if (_DbTransaction != null)
                await _DbTransaction?.CommitAsync();
            _DbTransaction = null;
            return this;
        }

        public IDBManager AddCMDParam(string parametername, object value)
        {
            _InputParam.Add(new()
            {
                ParamName = parametername,
                Value = value
            });
            return this;
        }
        public IDBManager AddCMDParam(string parametername, object value, DbType dbtype)
        {
            _InputParam.Add(new()
            {
                ParamName = parametername,
                Value = value,
                DbType = dbtype
            });
            return this;
        }

        public IDBManager AddCMDOutParam(string parametername, DbType dbtype)
        {
            _OutParam.Add(new()
            {

                ParamName = parametername,
                DbType = dbtype
            });
            return this;
        }

        public DataTable ExecuteDataTable()
        {
            DataTable result = null;
            using (DbCommand _DbCommand = CreateDbCMD())
            {
                Open();
                try
                {
                    result = _DbCommand.ExecuteDataTable();
                    GetOutParam(_DbCommand);
                }
                catch (Exception ex)
                {
                    Rollback(_DbCommand, ex);
                }
            }
            return result;
        }

        public DataSet ExecuteDataSet()
        {
            DataSet result = null;
            //using (DbCommand _DbCommand = CreateDbCMD())
            //{
            //    Open();
            //    try
            //    {
            //        result = _DbCommand.ExecuteDataSet();
            //        GetOutParam(_DbCommand);
            //    }
            //    catch (Exception ex)
            //    {
            //        Rollback(_DbCommand, ex);
            //    }
            //}
            return result;
        }

        public object? ExecuteScalar()
        {
            object? result = null;

            using (DbCommand _DbCommand = CreateDbCMD())
            {
                Open();
                try
                {
                    result = _DbCommand.ExecuteScalar();
                    GetOutParam(_DbCommand);
                }
                catch (Exception ex)
                {
                    Rollback(_DbCommand, ex);
                }
            }
            return result;
        }

        public async Task<object?> ExecuteScalarAsync()
        {
            object? result = null;
            using (DbCommand _DbCommand = CreateDbCMD())
            {
                Open();
                try
                {
                    result = await _DbCommand.ExecuteScalarAsync();
                    GetOutParam(_DbCommand);
                }
                catch (Exception ex)
                {
                    await RollbackAsync(_DbCommand, ex);
                }
            }
            return result;
        }

        public int ExecuteNonQuery()
        {
            int result = -1;

            using (DbCommand _DbCommand = CreateDbCMD())
            {
                Open();
                try
                {
                    result = _DbCommand.ExecuteNonQuery();
                    GetOutParam(_DbCommand);
                }
                catch (Exception ex)
                {
                    Rollback(_DbCommand, ex);
                }
            }

            return result;
        }

        public async Task<int> ExecuteNonQueryAsync()
        {
            int result = -1;
            using (DbCommand _DbCommand = CreateDbCMD())
            {
                Open();
                try
                {
                    result = await _DbCommand.ExecuteNonQueryAsync();
                    GetOutParam(_DbCommand);
                }
                catch (Exception ex)
                {
                    await RollbackAsync(_DbCommand, ex);
                }
            }
            return result;
        }
        DbCommand CreateDbCMD()
        {
            DbCommand _DbCommand = _DbConnection.CreateDbCMD(_DBCmd, _CommandType);
            _DbCommand.Transaction = _DbTransaction;
            AddInputPara(_DbCommand);
            AddOutputParam(_DbCommand);
            return _DbCommand;
        }

        void AddInputPara(DbCommand _DbCommand)
        {
            foreach (DBParam item in _InputParam)
            {
                if (item.DbType.HasValue)
                    _DbCommand.AddCMDParam(item.ParamName, item.Value, (DbType)item.DbType);
                else
                    _DbCommand.AddCMDParam(item.ParamName, item.Value);
            }
        }

        void AddOutputParam(DbCommand _DbCommand)
        {
            foreach (DBParam item in _OutParam)
            {
                _DbCommand.AddCMDOutParam(item.ParamName, (DbType)item.DbType);
            }
        }

        void GetOutParam(DbCommand _DbCommand)
        {
            foreach (DBParam item in _OutParam)
            {
                item.Value = _DbCommand.Parameters[item.ParamName].Value.ToString();
            }
        }

        public T GetOutParam<T>(string paramname)
        {
            object result = null;
            DBParam outparam = _OutParam.Where(a => a.ParamName == paramname).FirstOrDefault();
            if (outparam != null)
            {
                switch (outparam.DbType)
                {
                    case DbType.Boolean:
                        string strval = outparam.Value.ToString();
                        if (strval.Length == 1)
                        {
                            result = strval == "1";
                        }
                        else
                        {
                            result = Convert.ToBoolean(outparam.Value);
                        }
                        break;
                    case DbType.Date:
                    case DbType.DateTime:
                        result = Convert.ToDateTime(outparam.Value);
                        break;
                    case DbType.Decimal:
                        result = Convert.ToDecimal(outparam.Value);
                        break;
                    case DbType.Double:
                        result = Double.Parse(outparam.Value.ToString());
                        break;
                    case DbType.Int16:
                        result = Convert.ToInt16(outparam.Value);
                        break;
                    case DbType.Int32:
                        result = Convert.ToInt32(outparam.Value);
                        break;
                    case DbType.Int64:
                        result = Convert.ToInt64(outparam.Value);
                        break;
                    case DbType.String:
                        result = Convert.ToString(outparam.Value);
                        break;
                }
            }
            return (T)result;
        }

        private class DBParam
        {
            public string ParamName { get; set; }
            public object? Value { get; set; }
            public DbType? DbType { get; set; }
        }

        void Rollback(DbCommand _DbCommand, Exception ex)
        {
            _DbTransaction?.Rollback();
            string errormessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            //_Logger.LogError(ex, errormessage);
            //_Logger.LogError(_DbCommand.CommandText);
            throw ex;

        }

        async Task RollbackAsync(DbCommand _DbCommand, Exception ex)
        {
            await _DbTransaction?.RollbackAsync();
            string errormessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            //_Logger.LogError(ex, errormessage);
            //_Logger.LogError(_DbCommand.CommandText);
            throw ex;

        }

    }
}
