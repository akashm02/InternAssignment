﻿
using MyWebAppDataManager.IDataManager;
using MyWebAppModels.Login;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.DataManager
{
    public class HomeRepository : IHomeRepository
    {
        readonly IDBManager _IDbManager;
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public bool ErrorMessage { get; private set; }

        public HomeRepository(IDBManager IDbManager)
        {
            _IDbManager = IDbManager;
        }


        #region Add User Details
        ///Created by Akash Mahato
        ///Created at 12th June 2023
        /// <summary>
        /// Add new User
        /// </summary>
        /// <param name="oModel"></param>
        /// <param name="currentLoginId"></param>
        /// <returns>Newly added user details</returns>
        public AddUserModel AddUser(AddUserModel oModel, int currentLoginId)
        {
            //AddUserModel adduserModel = null;

            //_IDbManager.InitDbCommand("add_user")
            //    .AddCMDParam("emailid_in", oModel.Email)
            //    .AddCMDOutParam("error_msg_out", DbType.String); // takes the error message from the database


            try
            {
                _IDbManager.InitDbCommand("add_user")
                    .AddCMDParam("created_by_in", currentLoginId)
                    .AddCMDParam("firstname_in", oModel.FirstName)
                    .AddCMDParam("lastname_in", oModel.LastName)
                    .AddCMDParam("emailid_in", oModel.Email)
                    .AddCMDParam("phone_in", oModel.PhoneNumber)
                    .AddCMDParam("userpassword_in", oModel.Password)    
                    
                    .AddCMDOutParam("error_msg_out", DbType.String);
                //.AddCMDParam("emailid_in", oModel.Email)
                //.AddCMDOutParam("error_msg_out", DbType.String); // takes the error message from the database

                _IDbManager.ExecuteNonQuery();
                oModel.ErrorMessage = _IDbManager.GetOutParam<string>("error_msg_out");

            }

            catch (Exception ex)
            {
                _logger.Info(ex.Message);
                //Console.WriteLine(ex.Message);  
            }


            return oModel;
        }
        #endregion




        #region Taking user details to show in home page
        /// <summary>
        /// Taking the user details from database for showing in table format
        /// </summary>
        /// <returns></returns>
        public List<UserListModel> GetUserList()
        {
            List<UserListModel> userlist = new List<UserListModel>();
            _IDbManager.InitDbCommand("sp_get_user_list");
            try {
                DataTable dt = _IDbManager.ExecuteDataTable();


                foreach (DataRow item in dt.Rows)
                {
                    UserListModel user = new UserListModel();
                    user.UserId = Convert.ToInt32(item["user_id"]);
                    user.FirstName = Convert.ToString(item["first_name"]);
                    user.LastName = Convert.ToString(item["last_name"]);
                    user.PhoneNumber = Convert.ToString(item["phone_number"]);
                    user.Email = Convert.ToString(item["email"]);
                    user.Created_by = Convert.ToDateTime(item["created_at"]);

                    userlist.Add(user);
                }

            }
            catch (Exception ex)
            {
                _logger.Info(ex.Message);
                //Console.WriteLine(ex.Message);  
            }


            return userlist;
        }
        #endregion


        public AddUserModel AddUser(AddUserModel oModel)
        {
            throw new NotImplementedException();
        }



        #region Collecting details from database
        /// <summary>
        /// Taking details from the user
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public GetUserModel GetUserDetail(int UserId)
        {
            GetUserModel usermodel = new GetUserModel();

            _IDbManager.InitDbCommand("sp_getuser_list_withid")
                .AddCMDParam("userid_in", UserId);


            try
            {
                DataTable dt = _IDbManager.ExecuteDataTable();

                //usermodel = new GetUserModel();

                foreach (DataRow item in dt.Rows)
                {

                    usermodel.UserId = Convert.ToInt32(item["user_id"]);
                    usermodel.FirstName = Convert.ToString(item["first_name"]);
                    usermodel.LastName = Convert.ToString(item["last_name"]);
                    usermodel.PhoneNumber = Convert.ToString(item["phone_number"]);
                    usermodel.Email = Convert.ToString(item["email"]);
                }

            }
            catch (Exception ex)
            {
                _logger.Info(ex.Message);
                //Console.WriteLine(ex.Message);  
            }


            return usermodel;
        }
        #endregion



        #region Updating user details in database
        /// <summary>
        /// Update the earlier data from database
        /// </summary>
        /// <param name="oModel"></param>
        /// <param name="currentLoginId"></param>
        /// <returns></returns>
        public GetUserModel EditUserDetail(GetUserModel oModel, int currentLoginId)
        {

            try
            {
                _IDbManager.InitDbCommand("sp_update_users_details")
                    .AddCMDParam("user_id_in", oModel.UserId)
                    .AddCMDParam("firstname_in", oModel.FirstName)
                    .AddCMDParam("lastname_in", oModel.LastName)
                    .AddCMDParam("email_in", oModel.Email)
                    .AddCMDParam("phone_in", oModel.PhoneNumber)
                    .AddCMDParam("current_user_id_in", currentLoginId)

                    .AddCMDOutParam("error_msg_out", DbType.String);
                //.AddCMDParam("emailid_in", oModel.Email)
                //.AddCMDOutParam("error_msg_out", DbType.String); // takes the error message from the database

                _IDbManager.ExecuteNonQuery();
                oModel.ErrorMessage = _IDbManager.GetOutParam<string>("error_msg_out");

            }

            catch (Exception ex)
            {
                _logger.Info(ex.Message);
                //Console.WriteLine(ex.Message);  
            }


            return oModel;
        }
        #endregion



        #region Delete User 
        /// Created by Akash Mahato
        /// Created at 16-6-2023
        /// <summary>
        /// Deleting user from the database by assigning boolean value
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>User who deleted frm the user shows with 1</returns>

        public bool DeleteUser(int userId)
        {
            bool isdeleted = false;
            _IDbManager.InitDbCommand("sp_delete_users")
                .AddCMDParam("user_id_in", userId)
                .AddCMDOutParam("update_msg", DbType.Boolean);

            try
            {
                _IDbManager.ExecuteNonQuery();
                 isdeleted = _IDbManager.GetOutParam<bool>("update_msg");
                
            }

            catch(Exception ex)
            {
                _logger.Info(ex.Message);
            }
            return isdeleted;
        }

        #endregion






    }

}

