﻿using MyWebAppDataManager.DataManager;
using MyWebAppDataManager.IDataManager;
using MyWebAppModels.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.IBAL
{
    public class LoginBAL : ILoginBAL
    {
        public LoginRepository _LoginRepository;

        public LoginBAL(IDBManager dbManager)
        {
            _LoginRepository = new LoginRepository(dbManager);
        }

        public UserModel LoginAuth(LoginModel oModel)
        {
            UserModel userModel = null;

            userModel = _LoginRepository.LoginAuth(oModel);

            return userModel;
        }
    }
}
