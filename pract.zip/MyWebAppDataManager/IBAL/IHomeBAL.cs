﻿using MyWebAppModels.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.IBAL
{
    public interface IHomeBAL
    {
        public AddUserModel AddUser(AddUserModel oModel, int currentLoginId);

        List<UserListModel> GetUserList();

        GetUserModel GetUserDetail(int UserId);

        GetUserModel EditUserDetail(GetUserModel oModel, int UserId);


        public bool DeleteUser(int userId);

    }
}
