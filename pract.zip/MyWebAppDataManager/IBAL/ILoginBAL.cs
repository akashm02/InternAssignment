﻿using MyWebAppModels.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.IBAL
{
    public interface ILoginBAL
    {
        UserModel LoginAuth(LoginModel oModel);
    }
}
