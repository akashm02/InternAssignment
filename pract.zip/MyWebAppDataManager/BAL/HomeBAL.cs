﻿using MyWebAppDataManager.DataManager;
using MyWebAppDataManager.IBAL;
using MyWebAppDataManager.IDataManager;
using MyWebAppModels.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.BAL
{
    public class HomeBAL : IHomeBAL
    {
        public HomeRepository _HomeRepository;

        public HomeBAL(IDBManager dbManager)
        {
            _HomeRepository = new HomeRepository(dbManager);
        }

        public AddUserModel AddUser(AddUserModel oModel, int currentLoginId)
        {
           oModel = _HomeRepository.AddUser(oModel, currentLoginId);
            return oModel;  
        }

        public GetUserModel EditUserDetail(GetUserModel oModel, int UserId)
        {
            oModel = _HomeRepository.EditUserDetail(oModel, UserId);
            return oModel;
        }

        public GetUserModel GetUserDetail(int UserId)
        {
            GetUserModel getUserModel = new GetUserModel();
            getUserModel = _HomeRepository.GetUserDetail(UserId);

            return getUserModel;
        }


        public List<UserListModel> GetUserList()
        {
            List<UserListModel> userList = new List<UserListModel>();
            userList = _HomeRepository.GetUserList(); 

            return userList;    
        }

        public bool DeleteUser(int userId)
        {
            return _HomeRepository.DeleteUser(userId);
        }
    }
}
