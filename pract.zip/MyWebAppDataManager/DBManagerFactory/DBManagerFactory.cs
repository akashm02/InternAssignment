﻿using MySql.Data.MySqlClient;
using MyWebAppDataManager.DataManager;
using MyWebAppDataManager.IDataManager;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyWebAppDataManager.DBManagerFactory
{
    public class DBManagerFactory
    {
        public IDBManager GetDBManager(string connectionString)
        {
            DbConnection dbconn = new MySqlConnection(connectionString);
            return new DBManager(dbconn);
        }
    }
}
