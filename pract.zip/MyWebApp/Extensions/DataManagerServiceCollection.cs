﻿using MyWebAppDataManager.BAL;
using MyWebAppDataManager.DBManagerFactory;
using MyWebAppDataManager.IBAL;
using MyWebAppDataManager.IDataManager;

namespace MyWebApp.Extensions
{
    internal static class ServiceCollectionExtension
    {

        public static IServiceCollection AddDataManagers(this IServiceCollection services)
        {
            services.AddScoped<IDBManager>(AddDBManager);

            services.AddScoped<ILoginBAL, LoginBAL>();

            services.AddScoped<IHomeBAL, HomeBAL>();


            
            return services;
        }



        internal static IDBManager AddDBManager(IServiceProvider serviceProvider)
        {
            IConfiguration Configuration = serviceProvider.GetRequiredService<IConfiguration>();



            string dbconstr = Configuration.GetConnectionString("DBConnectionString");
            return new DBManagerFactory().GetDBManager(dbconstr);
        }



        //internal static IServiceCollection AddAppsettings(this IServiceCollection services,IConfiguration configuration)
        //{
        //    EnvironmentVariableTarget target = EnvironmentVariableTarget.Process;



        //    string conStr = configuration["DBConnectionString"];
        //    Environment.SetEnvironmentVariable("DBConnectionString",conStr,target);



        //    return services;
        //}
    }
}
