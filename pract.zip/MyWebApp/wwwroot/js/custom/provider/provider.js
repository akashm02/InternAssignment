﻿$(document).ready(function () {

    console.log("Modal loaded")

    $('#btn-add').click(function () {
        console.log("button clicked")

        $("#form-provider").validator('validate');
        if ($("#form-provider").has('.has-error')[0]) {
            return false;
        }
        else {
            
        }
    });
});


function OpenProviderModal() {
    document.getElementById("btn-add");
    $('#addProviderModal').modal('show');
}

function CloseProviderModal() {
    $('#addProviderModal').modal('hide');
}