﻿$(document).ready(function () {
    console.log("js loaded here");

    $('#btn-login').click(function () {
        //submit();

        $("#form-Login").validator('validate');
        if ($("#form-Login").has('.has-error')[0]) {
            return false;
        }
        else {
            submit();
        }
    });


});

function BindModel() {
        var model = {};

        model.Username = $('#txt-login-Username').val();
        model.Password = $('#txt-login-Password').val();

        return model;
    }

 function submit()
 {
     var model = BindModel();

     $.ajax({
         url: "/Login/Auth",
         type: "POST",
         contentType: "application/json",
         data: JSON.stringify(model),
         dataType: 'json',
         success: function (result) {
             debugger
             if (result != null) {

                 if (result.ErrorMessage != "") {
                     alert(result.ErrorMessage);
                 }
                 else {
                     location.href = "/Home";
                 }
             }
             
           
             debugger
         },
         error: function (data) {
             debugger
         }
     });

  }