﻿var userListTable;
$(document).ready(function () {

    console.log("Modal loaded")

    $('#btn-add').click(function () {
        console.log("button clicked")

        $("#form-Login").validator('validate');
        if ($("#form-Login").has('.has-error')[0]) {
            return false;
        }
        else {
            submitadd();
        }
    });

    userListTable = $("#user_list_table").DataTable({
        paging: false,
        info: false,
        filter: false,
        data: [],
        columns: [
            { data: 'FirstName' },

            { data: 'LastName' },

            { data: 'Email' },

            { data: 'PhoneNumber' },

            { data: 'Created_by' },

            {
                data: null,
                className: "text-center",
                render: function (data, type, row) {
                    if (type === 'display') {
                        return `<ul class="list-unstyled hstack gap-1 mb-0">
                               <li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">
                                                                                    <a onclick="OpenEditUserForUserList(${row.UserId})" class="btn btn-sm btn-soft-primary"><i class="mdi mdi-pencil-outline"></i></a>
                                                                                </li>
                                                                                <li data-bs-toggle="tooltip" data-bs-placement="top" title="Delete">
                                                                                    <a onclick="DeleteUser(${row.UserId})" class="btn btn-sm btn-soft-danger"><i class="mdi mdi-delete-outline"></i></a>
                                                                                </li>
                                                                            </ul>`;
                    }
                    else {
                        return data;
                    }
                }
            }

        ],
    });

    GetUserDetailslist();
});


//for update
$(document).ready(function () {
    console.log("Modal update loaded")

    $('#btn-edit').click(function () {
        console.log("button clicked")

        $("#form-edit").validator('validate');
        if ($("#form-edit").has('.has-error')[0]) {
            return false;
        }
        else {
            updateuser();
        }
    });
});

function OpenAddUserModal() {
    document.getElementById("form-Login").reset();
    ResetValidation();
    $('#addUserModal').modal('show');
}


/*---------------Edit user-------------*/
function OpenEditUserModal() {
    ResetValidation();
    $('#editUserModal').modal('show');
}
/*-------------------------------------*/

function ResetValidation() {
    //removes validation from user input

    $(".error-text").each(function () {
        $(this).children().remove()
    });
}

function CloseAddUserModal() {
    $('#addUserModal').modal('hide');
}


/*---------------Close Edit user-------------*/
function CloseEditUserModal()
{
    $('#editUserModal').modal('hide');
}
/*--------------------------------------------*/

function BindAddModel() {
    var model = {};

    model.FirstName = $('#name2').val();
    model.LastName = $('#name3').val();
    model.Email = $('#email2').val();
    model.PhoneNumber = $('#phone1').val();
    model.Password = $('#password2').val();

    return model;
}


function BindUpdateModel() {
    var model = {};

    model.UserId = parseInt($("#hd-edit-user-id").val());
    model.FirstName = $('#editname').val();
    model.LastName = $('#editname2').val();
    model.Email = $('#editemail').val();
    model.PhoneNumber = $('#editphone').val();

    return model;
}

function updateuser() {
    var model = BindUpdateModel();

    $.ajax({
        url: "/Home/EditUserDetail", //home controller function
        type: "PUT",
        contentType: "application/json",
        data: JSON.stringify(model),
        dataType: 'json',
        success: function (result) {
            debugger
            if (result != null) {

                if (result.ErrorMessage != "") {
                    alert(result.ErrorMessage);
                }
                else {
                    alert("User updated Succesfully");
                    CloseEditUserModal();
                    GetUserDetailslist();

                }
            }
            debugger
        },
        error: function (data) {
            debugger
        }
    });
}

function DeleteUser(UserId) {
    $.ajax({

        url: "/Home/DeleteUser?userId=" + UserId,
        type: "delete",
        dataType: "json",
        contentType: "application/json",
        cache: false,
        async: false,
        success: function (result) {
            if (result == true) {
                alert("User deleted succesfully");
                GetUserDetailslist();
            }
            else {
                alert("User not found");
            }
            
        },
        error: function (xhr, status, error) {
            if (xhr.status == 462) {
                AuthenticateUser(xhr.responseJSON);
            } else if (xhr.status == 463) {
                CookieNotFound(xhr.responseJSON);
            }
        }
    });
}


function submitadd() {
    var model = BindAddModel();

    $.ajax({
        url: "/Home/AddUser", //home controller function
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(model),
        dataType: 'json',
        success: function (result) {
            debugger
            if (result != null) {

                if (result.ErrorMessage != "") {
                    alert(result.ErrorMessage);
                }
                else {
                    alert("User added Succesfully");
                    location.href = "/Home";
                }
            }
            debugger
        },
        error: function (data) {
            debugger
        }
    });

}

function GetUserDetailslist() {
    $.ajax({
        url: "/Home/GetUserList",
        type: "GET",
        contentType: "application/json",
        success: function (result) {

            userListTable.clear().rows.add(result).draw(false);
        },
        error: function (xhr, status, error) {
            if (xhr.status == 462) {
                AuthenticateUser(xhr.responseJSON);
            } else if (xhr.status == 463) {
                CookieNotFound(xhr.responseJSON);
            }
        }
    });
}



function OpenEditUserForUserList(UserId) {
    OpenEditUserModal();
    var oModel = GetUserDetails(UserId);
    BindUserModalForEdit(oModel);
    debugger
}


//function DeleteKeyword(UserId) {
//    $(this).closest('tr').remove();
//}



function BindUserModalForEdit(oModel) {
    debugger
    $("#hd-edit-user-id").val(oModel.UserId);
    $("#editname").val(oModel.FirstName);
    $("#editname2").val(oModel.LastName);
    $("#editemail").val(oModel.Email);
    $("#editphone").val(oModel.PhoneNumber);
}

function GetUserDetails(UserId) {

    var oResult;
    $.ajax({
        url: "/Home/GetUserDetail?userId=" + UserId ,
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        cache: false,
        async: false,
        success: function (result) {

            oResult = result;
        },
        error: function (xhr, status, error) {
            if (xhr.status == 462) {
                AuthenticateUser(xhr.responseJSON);
            } else if (xhr.status == 463) {
                CookieNotFound(xhr.responseJSON);
            }
        }
    });
    return oResult;
}