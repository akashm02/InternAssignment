﻿using Microsoft.AspNetCore.Mvc;

namespace MyWebApp.Controllers
{
    public class AddUserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AddUser()
        {
            return View();
        }
    }
}
