﻿using MyWebAppModels.Login;
using Microsoft.AspNetCore.Mvc;
using MyWebAppDataManager.IBAL;
using Newtonsoft.Json;

namespace MyWebApp.Controllers
{
    public class LoginController : Controller
    {
        private readonly ILoginBAL _ILoginBAL;  
        
        public LoginController(ILoginBAL iLoginBAL)
        {
            _ILoginBAL = iLoginBAL; 
        }
        public IActionResult Index()
        {
            return View("~/Views/Login/Login.cshtml");
        }

        [HttpPost]

        public IActionResult Auth([FromBody] LoginModel model)
        {
            // data saved here in user object
            UserModel user = _ILoginBAL.LoginAuth(model);   

            //checks user and create user

            if (user != null) {
                UserSessionModel userSessionModel = new UserSessionModel();
                userSessionModel.FirstName = user.FirstName;    
                userSessionModel.LastName = user.LastName;  
                userSessionModel.Email = user.Email;
                userSessionModel.Phonenumber = user.PhoneNumber;
                userSessionModel.UserId = user.UserId;


                //set session details 

                HttpContext.Session.SetString("MySession", JsonConvert.SerializeObject(userSessionModel));  


            }
            return Json(user);
        }
    }
}

