﻿using Microsoft.AspNetCore.Mvc;
using MyWebApp.Models;
using MyWebAppDataManager.IBAL;
using MyWebAppModels.Login;
using Newtonsoft.Json;
using System.Diagnostics;

namespace MyWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHomeBAL _IHomeBAL;

        public HomeController(ILogger<HomeController> logger, IHomeBAL iHomeBAL)
        {
            _logger = logger;
            _IHomeBAL = iHomeBAL;
        }

        public IActionResult Index()
        {

            //get session details from login controller 

            //if (HttpContext.Session.Keys.Contains("MySession"))
            //{
            //    UserSessionModel userSession = JsonConvert.DeserializeObject<UserSessionModel>(HttpContext.Session.GetString("MySession"));
            //}
            return View();
        }

        [HttpPost]

        public JsonResult AddUser([FromBody] AddUserModel oModel)
        {
            if (HttpContext.Session.Keys.Contains("MySession")) 
            {
                UserSessionModel userSession = JsonConvert.DeserializeObject<UserSessionModel>(HttpContext.Session.GetString("MySession"));

                if (userSession != null) {
                    int currentLoginId = userSession.UserId;
                    oModel = _IHomeBAL.AddUser(oModel, currentLoginId);
                }
            }

            return Json(oModel);
        }


        // for taking data from database to table
        [HttpGet]

        public JsonResult GetUserList()
        {

            List<UserListModel> userList = new List<UserListModel>();
            userList = _IHomeBAL.GetUserList();

            return Json(userList);  
        }


        // for taking data from database to save 
        [HttpGet]

        public JsonResult GetUserDetail(int userId)
        
        {
            GetUserModel getUser = new GetUserModel();
            getUser = _IHomeBAL.GetUserDetail(userId);
            return Json(getUser);
        }


        [HttpPut]

        public JsonResult EditUserDetail([FromBody] GetUserModel oModel)
        {
            if (HttpContext.Session.Keys.Contains("MySession"))
            {
                UserSessionModel userSession = JsonConvert.DeserializeObject<UserSessionModel>(HttpContext.Session.GetString("MySession"));

                if (userSession != null)
                {
                    int currentLoginId = userSession.UserId;
                    oModel = _IHomeBAL.EditUserDetail(oModel, currentLoginId);
                }
            }

            return Json(oModel);
        }


        [HttpDelete]

        public JsonResult DeleteUser(int userId)
        {

            bool isDeleted = false;
            //if (HttpContext.Session.Keys.Contains("MySession"))
            //{
            //    UserSessionModel userSession = JsonConvert.DeserializeObject<UserSessionModel>(HttpContext.Session.GetString("MySession"));

            //    if (userSession != null)
            //    {
            //        int currentLoginId = userSession.UserId;
            //         = _IHomeBAL.DeleteUser(UserId);
            //    }
            //}

            isDeleted = _IHomeBAL.DeleteUser(userId);
            return Json(isDeleted);
        }



        public IActionResult Privacy()
        {
            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}